# JET DNN

`pip install jetdnn`

JETDNN: Python package using Deep Neural Networks (DNNs) to find H-mode plasma pedestal heights from multiple engineering parameters.

For documentation, see: ____


